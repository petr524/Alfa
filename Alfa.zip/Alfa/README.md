Fractal Generator: Mandelbrot and Julia Sets

Table of Contents
1. Project Overview
2. Author Information
3. User Requirements Specification
4. System Architecture
  - Design Patterns 
  - UML Structural Diagrams
5. System Usage and Operation 
  - Configuration 
  - Installation and Startup Instructions 
  - Error Handling 
6. Third-Party Libraries
7. Testing and Reports
  - Unit Tests 
  - Bug Reports
8. Conclusion

1. Project Overview
The Fractal Generator is a Python-based application designed to generate visual representations of the Mandelbrot and Julia sets. Utilizing parallel processing techniques, the application efficiently computes complex fractal images, allowing users to customize various parameters such as image resolution, color schemes, and computational strategies. This project serves as a comprehensive exploration of fractal mathematics, parallel computing, and software engineering principles.


2. Author Information
Name: Petr Bejček
Class: C4b
Email: Bejcekpetr62@gmail.com
GitHub: https://github.com/petr524
3. User Requirements Specification
 Functional Requirements
  1. Fractal Generation:
     - Generate Mandelbrot and Julia set fractals based on user-defined parameters.
     - Support customizable image resolution and zoom levels.
  2. Color Schemes:
     - Provide multiple color schemes to visualize fractals differently.
     - Allow users to select and configure color schemes via configuration files.
  3. Parallel Processing:
     - Utilize multithreading or multiprocessing to enhance computation speed.
     - Enable users to choose the parallel processing strategy and the number of threads/processes.
  4. Configuration:
     - Use INI-based configuration files to allow easy customization of parameters.
     - Validate configuration parameters and provide meaningful error messages.
  5. Output:
     - Save generated fractal images in PNG format.
     - Log performance metrics and errors for analysis.
Non-Functional Requirements
  1. Performance:
     - Optimize fractal calculations to minimize computation time.
     - Efficiently manage system resources during parallel processing.
  2. Usability:
     - Provide clear documentation and user-friendly configuration options.
     - Ensure the application handles errors gracefully and informs the user appropriately.
  3. Maintainability:
     - Write clean, modular code adhering to best software engineering practices.
     - Include comprehensive unit tests to facilitate future enhancements and debugging.

4. System Architecture
Design Patterns
The Fractal Generator employs several design patterns to ensure a robust and scalable architecture:

  1. Factory Pattern:
     - used in the ColorSchemes class to instantiate appropriate color function objects based on user selection.
  2. Strategy Pattern:
     - Implemented in the parallel processing module to allow interchangeable computation strategies (e.g., threading vs. multiprocessing).
  3. Singleton Pattern:
     - Applied in the LoggerWrapper class to ensure a single instance of the logger is used throughout the application.

5. System Usage and Operation
Configuration
The application uses INI-formatted configuration files to allow users to customize various aspects of fractal generation. Below is an example configuration:

ini

[Image]
width=800
height=600

[Fractal]
type=julia
center_x=0.0
center_y=0.0
zoom=2.0
max_iterations=800
julia_cx=-0.8
julia_cy=0.156

[Parallel]
strategy=process
thread_count=6

[Output]
file=julia_alt_output.png

[Logging]
file=julia_alt.log

[Color]
scheme=redish
Configuration Parameters
- Image:
  - width: Width of the output image in pixels.
  - height: Height of the output image in pixels.
- Fractal:
  - type: Type of fractal to generate (mandelbrot or julia).
  - center_x: X-coordinate of the fractal's center.
  - center_y: Y-coordinate of the fractal's center.
  - zoom: Zoom level for fractal generation.
  - max_iterations: Maximum number of iterations to determine set membership.
  - julia_cx: Constant X value for Julia set calculations.
  - julia_cy: Constant Y value for Julia set calculations.
- Parallel:
  - strategy: Parallel processing strategy (thread or process).
  - thread_count: Number of threads or processes to use.
- Output:
  - file: Name of the output PNG file.
- Logging:
  - file: Name of the log file.
- Color:
  - scheme: Color scheme to apply (default, blueish, redish, greenish).
Installation and Startup Instructions
Prerequisites
- Python Version: Python 3.8 or higher
- Dependencies: Listed in requirements.txt
Installation Steps

- bash
pip install -r requirements.txt
Running the Application
Execute the application by specifying a configuration file:

- bash
python -m app.main --config config.properties.mandelbrot
Replace config.properties.mandelbrot with your desired configuration file.

Error Handling
The application includes comprehensive error handling to ensure smooth user experience:

Configuration Errors:
 - Missing or invalid configuration parameters will trigger informative error messages.
 - Example Error:
   Configuration error: max_iterations must be a positive integer.
Runtime Errors:
 - Issues during fractal computation or file I/O are logged and displayed to the user.
 - Example Error:
   Unexpected error: Unable to write to output file.
Logging of Errors:
 - All errors are logged in the specified log file ([Logging].file parameter).
Error Codes:
 - Specific error codes are used to identify and troubleshoot issues quickly.
 - Example:
   Error Code 1001: Invalid fractal type specified.

6. Third-Party Libraries
The Fractal Generator leverages several third-party libraries to enhance functionality and performance:
  - NumPy: For efficient numerical computations and array manipulations.
  - Pillow: For image creation and manipulation.
  - ConfigParser: To parse INI configuration files.
  - Logging: For robust logging mechanisms.
  - Unittest: To implement unit testing.
  - Concurrent.futures: To manage parallel execution strategies.

7. Testing and Reports
Unit Tests
Comprehensive unit tests have been implemented using Python's unittest framework to ensure the reliability and correctness of the application. The tests cover:
- Color Schemes:
  - Verifying that each color function returns the correct RGB values based on iteration counts.
- Configuration Validation:
  - Ensuring that configuration parameters are correctly parsed and validated.
- Parallel Processing:
  - Testing both threading and multiprocessing strategies for accurate and efficient computation.

Bug Reports
  1. Pickling Error with Lambda Functions:
    - Description: Encountered Can't pickle local object 'ColorSchemes.get_color_func.<locals>.color_func' when using ProcessPoolExecutor.
    - Resolution: Refactored color functions into top-level classes with __call__ methods to ensure picklability.
  2. Missing time Module Import:
    - Description: Error name 'time' is not defined during fractal calculation.
    - Resolution: Added import time statements in mandelbrot_calculator.py and julia_calculator.py.

Conclusion
The Fractal Generator successfully demonstrates the generation of Mandelbrot and Julia set fractals using Python's robust computational and parallel processing capabilities. Through careful architectural design, the application ensures efficiency, scalability, and user flexibility. Comprehensive documentation, coupled with thorough testing, guarantees a reliable and maintainable codebase. Future enhancements will focus on expanding functionality, optimizing performance, and enhancing user experience.
