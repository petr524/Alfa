# src/app/calculation/color_schemes.py

class DefaultColorFunc:
    """
    Default color function for Mandelbrot and Julia sets.
    - Points inside the set are colored black.
    - Points outside the set have colors based on their iteration count.
    """

    def __init__(self, max_iter):
        """
        Initialize the DefaultColorFunc with the maximum number of iterations.

        :param max_iter: Maximum number of iterations to determine set membership.
        """
        self.max_iter = max_iter

    def __call__(self, it):
        """
        Determine the color based on the iteration count.

        :param it: Number of iterations for the point.
        :return: Tuple representing the RGB color.
        """
        if it == self.max_iter:
            return (0, 0, 0)  # Black for points inside the set
        else:
            return (it % 256, (it * 5) % 256, (it * 13) % 256)  # Color gradient


class BlueishColorFunc:
    """
    Blueish color scheme.
    - Gradually increases the blue component based on iteration count.
    """

    def __init__(self, max_iter):
        """
        Initialize the BlueishColorFunc with the maximum number of iterations.

        :param max_iter: Maximum number of iterations to determine set membership.
        """
        self.max_iter = max_iter

    def __call__(self, it):
        """
        Determine the blueish color based on the iteration count.

        :param it: Number of iterations for the point.
        :return: Tuple representing the RGB color.
        """
        return (0, 0, int(255 * it / self.max_iter))  # Increasing blue


class RedishColorFunc:
    """
    Redish color scheme.
    - Gradually increases the red component based on iteration count.
    """

    def __init__(self, max_iter):
        """
        Initialize the RedishColorFunc with the maximum number of iterations.

        :param max_iter: Maximum number of iterations to determine set membership.
        """
        self.max_iter = max_iter

    def __call__(self, it):
        """
        Determine the reddish color based on the iteration count.

        :param it: Number of iterations for the point.
        :return: Tuple representing the RGB color.
        """
        return (int(255 * it / self.max_iter), 0, 0)  # Increasing red


class GreenishColorFunc:
    """
    Greenish color scheme.
    - Gradually increases the green component based on iteration count.
    """

    def __init__(self, max_iter):
        """
        Initialize the GreenishColorFunc with the maximum number of iterations.

        :param max_iter: Maximum number of iterations to determine set membership.
        """
        self.max_iter = max_iter

    def __call__(self, it):
        """
        Determine the greenish color based on the iteration count.

        :param it: Number of iterations for the point.
        :return: Tuple representing the RGB color.
        """
        return (0, int(255 * it / self.max_iter), 0)  # Increasing green


class FallbackColorFunc:
    """
    Fallback color scheme.
    - Provides a simple color gradient when an unknown scheme is specified.
    """

    def __init__(self, max_iter):
        """
        Initialize the FallbackColorFunc with the maximum number of iterations.

        :param max_iter: Maximum number of iterations to determine set membership.
        """
        self.max_iter = max_iter

    def __call__(self, it):
        """
        Determine the fallback color based on the iteration count.

        :param it: Number of iterations for the point.
        :return: Tuple representing the RGB color.
        """
        return (it % 256, (it * 2) % 256, (it * 4) % 256)  # Simple gradient


class ColorSchemes:
    """
    Factory class to retrieve the appropriate color function based on the scheme name.
    """

    @staticmethod
    def get_color_func(scheme, max_iter):
        """
        Retrieve the color function instance corresponding to the specified scheme.

        :param scheme: Name of the color scheme ('default', 'blueish', 'redish', 'greenish').
        :param max_iter: Maximum number of iterations to determine set membership.
        :return: Instance of a color function class.
        """
        if scheme == 'default':
            return DefaultColorFunc(max_iter)
        elif scheme == 'blueish':
            return BlueishColorFunc(max_iter)
        elif scheme == 'redish':
            return RedishColorFunc(max_iter)
        elif scheme == 'greenish':
            return GreenishColorFunc(max_iter)
        else:
            return FallbackColorFunc(max_iter)
