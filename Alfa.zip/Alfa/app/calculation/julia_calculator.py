# src/app/calculation/julia_calculator.py

import time
import numpy as np
from app.calculation.color_schemes import ColorSchemes


class JuliaCalculator:
    """
    Julia calculation coordinator.
    Extended to measure execution time and log performance metrics.
    """

    def __init__(self, config, strategy, logger):
        """
        Initialize the JuliaCalculator with configuration, parallel strategy, and logger.

        :param config: Configuration object containing settings.
        :param strategy: Parallel strategy instance (ThreadPoolStrategy or ProcessPoolStrategy).
        :param logger: Logger instance for logging information and warnings.
        """
        self.config = config
        self.strategy = strategy
        self.logger = logger
        self.color_func = ColorSchemes.get_color_func(self.config.color_scheme, self.config.max_iter)

    def _julia_func(self, cx, cy, max_iter):
        """
        Create a function to compute iterations for the Julia set.

        :param cx: Constant X value for Julia set calculation.
        :param cy: Constant Y value for Julia set calculation.
        :param max_iter: Maximum number of iterations.
        :return: Function that computes iterations for given x0 and y0.
        """

        def compute_iterations(x0, y0):
            x, y = x0, y0
            iteration = 0
            while x * x + y * y <= 4.0 and iteration < max_iter:
                x_new = x * x - y * y + cx
                y = 2 * x * y + cy
                x = x_new
                iteration += 1
            return iteration

        return compute_iterations

    def calculate(self):
        """
        Perform the Julia set calculation using the specified parallel strategy.

        :return: Numpy array representing the RGB image of the Julia set.
        """
        self.logger.info("Starting Julia calculation...")
        start_time = time.time()

        segment_size = self.config.height // self.config.thread_count
        tasks = []
        julia_iter_func = self._julia_func(
            self.config.julia_cx, self.config.julia_cy, self.config.max_iter
        )
        for i in range(self.config.thread_count):
            start_row = i * segment_size
            end_row = start_row + segment_size
            if i == self.config.thread_count - 1:
                end_row = self.config.height
            task = JuliaWorkerTask(
                start_row, end_row,
                self.config.width, self.config.height,
                self.config.center_x, self.config.center_y,
                self.config.zoom, self.config.max_iter,
                self.color_func, julia_iter_func
            )
            tasks.append(task)

        results = self.strategy.run_tasks(tasks)
        results.sort(key=lambda x: x[0])

        image = np.zeros((self.config.height, self.config.width, 3), dtype=np.uint8)
        current_row = 0
        for start, data in results:
            rows = data.shape[0]
            image[current_row:current_row + rows, :, :] = data
            current_row += rows

        end_time = time.time()
        elapsed = end_time - start_time
        self.logger.info(f"Julia calculation finished in {elapsed:.2f} seconds.")

        # Log performance to CSV if supported
        if hasattr(self.logger, 'log_performance_csv'):
            self.logger.log_performance_csv('performance_log.csv', {
                'fractal': 'julia',
                'width': self.config.width,
                'height': self.config.height,
                'max_iter': self.config.max_iter,
                'strategy': self.config.parallel_strategy,
                'thread_count': self.config.thread_count,
                'time_seconds': elapsed
            })

        return image


class JuliaWorkerTask:
    """
    Worker task for calculating Julia set segments.
    """

    def __init__(self, start_row, end_row, width, height, center_x, center_y, zoom, max_iter, color_func, iter_func):
        """
        Initialize the JuliaWorkerTask with necessary parameters.

        :param start_row: Starting row of the image segment.
        :param end_row: Ending row of the image segment.
        :param width: Width of the image.
        :param height: Height of the image.
        :param center_x: X-coordinate of the fractal center.
        :param center_y: Y-coordinate of the fractal center.
        :param zoom: Zoom level.
        :param max_iter: Maximum iterations.
        :param color_func: Callable for determining pixel color based on iteration count.
        :param iter_func: Function to compute iterations for Julia set.
        """
        self.start_row = start_row
        self.end_row = end_row
        self.width = width
        self.height = height
        self.center_x = center_x
        self.center_y = center_y
        self.zoom = zoom
        self.max_iter = max_iter
        self.color_func = color_func
        self.iter_func = iter_func

    def __call__(self):
        """
        Compute the color data for the assigned image segment.

        :return: Tuple containing the starting row and the computed image data.
        """
        rows = self.end_row - self.start_row
        result = np.zeros((rows, self.width, 3), dtype=np.uint8)
        for row in range(self.start_row, self.end_row):
            cy = (row - self.height / 2.0) / (0.5 * self.zoom * self.height) + self.center_y
            for col in range(self.width):
                cx = (col - self.width / 2.0) / (0.5 * self.zoom * self.width) + self.center_x
                iteration = self.iter_func(cx, cy)
                color = self.color_func(iteration)
                result[row - self.start_row, col, :] = color
        return (self.start_row, result)
