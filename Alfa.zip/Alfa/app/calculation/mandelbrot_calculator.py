# src/app/calculation/mandelbrot_calculator.py

import time
import numpy as np
from app.calculation.worker_task import WorkerTask
from app.calculation.color_schemes import ColorSchemes


class MandelbrotCalculator:
    """
    Mandelbrot calculation coordinator.
    Extended to measure execution time and log performance metrics to CSV.
    """

    def __init__(self, config, strategy, logger):
        """
        Initialize the MandelbrotCalculator with configuration, parallel strategy, and logger.

        :param config: Configuration object containing settings.
        :param strategy: Parallel strategy instance (ThreadPoolStrategy or ProcessPoolStrategy).
        :param logger: Logger instance for logging information and warnings.
        """
        self.config = config
        self.strategy = strategy
        self.logger = logger
        self.color_func = ColorSchemes.get_color_func(self.config.color_scheme, self.config.max_iter)

    def calculate(self):
        """
        Perform the Mandelbrot set calculation using the specified parallel strategy.

        :return: Numpy array representing the RGB image of the Mandelbrot set.
        """
        self.logger.info("Starting mandelbrot calculation...")
        start_time = time.time()

        segment_size = self.config.height // self.config.thread_count
        tasks = []
        start_row = 0
        for i in range(self.config.thread_count):
            end_row = start_row + segment_size
            if i == self.config.thread_count - 1:
                end_row = self.config.height
            task = WorkerTask(
                start_row, end_row,
                self.config.width, self.config.height,
                self.config.center_x, self.config.center_y,
                self.config.zoom, self.config.max_iter,
                self.color_func
            )
            tasks.append(task)
            start_row = end_row

        results = self.strategy.run_tasks(tasks)
        results.sort(key=lambda x: x[0])

        image = np.zeros((self.config.height, self.config.width, 3), dtype=np.uint8)
        current_row = 0
        for start, data in results:
            rows = data.shape[0]
            image[current_row:current_row + rows, :, :] = data
            current_row += rows

        end_time = time.time()
        elapsed = end_time - start_time
        self.logger.info(f"Mandelbrot calculation finished in {elapsed:.2f} seconds.")

        # Log performance to CSV if supported
        if hasattr(self.logger, 'log_performance_csv'):
            self.logger.log_performance_csv('performance_log.csv', {
                'fractal': 'mandelbrot',
                'width': self.config.width,
                'height': self.config.height,
                'max_iter': self.config.max_iter,
                'strategy': self.config.parallel_strategy,
                'thread_count': self.config.thread_count,
                'time_seconds': elapsed
            })

        return image
