class MandelbrotMath:
    """
    Třída s matematickými metodami pro výpočet počtu iterací mandelbrotovy množiny.
    """
    @staticmethod
    def compute_iterations(cx, cy, max_iter):
        x, y = 0.0, 0.0
        iteration = 0
        while x*x + y*y <= 4.0 and iteration < max_iter:
            x_new = x*x - y*y + cx
            y = 2*x*y + cy
            x = x_new
            iteration += 1
        return iteration
