from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

class ParallelStrategy:
    """
    Abstraktní třída pro paralelní strategii.
    """
    def run_tasks(self, tasks):
        raise NotImplementedError()

class ThreadPoolStrategy(ParallelStrategy):
    """
    Strategie využívající vlákna (ThreadPoolExecutor).
    """
    def __init__(self, thread_count):
        self.thread_count = thread_count

    def run_tasks(self, tasks):
        results = []
        with ThreadPoolExecutor(max_workers=self.thread_count) as executor:
            futures = [executor.submit(t) for t in tasks]
            for f in futures:
                results.append(f.result())
        return results

class ProcessPoolStrategy(ParallelStrategy):
    """
    Strategie využívající procesy (ProcessPoolExecutor).
    """
    def __init__(self, process_count):
        self.process_count = process_count

    def run_tasks(self, tasks):
        results = []
        with ProcessPoolExecutor(max_workers=self.process_count) as executor:
            futures = [executor.submit(t) for t in tasks]
            for f in futures:
                results.append(f.result())
        return results
