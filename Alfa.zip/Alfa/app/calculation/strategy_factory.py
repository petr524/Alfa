from app.calculation.parallel_strategy import ThreadPoolStrategy, ProcessPoolStrategy

class StrategyFactory:
    """
    Factory třída pro vytvoření konkrétní paralelizační strategie na základě konfigurace.
    """
    @staticmethod
    def create(strategy_type, workers):
        if strategy_type == 'thread':
            return ThreadPoolStrategy(workers)
        elif strategy_type == 'process':
            return ProcessPoolStrategy(workers)
        else:
            # Default fallback na vlákna
            return ThreadPoolStrategy(workers)
