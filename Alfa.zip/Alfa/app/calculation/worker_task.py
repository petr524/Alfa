
# src/app/calculation/worker_task.py

import numpy as np
from app.calculation.mandelbrot_math import MandelbrotMath

class WorkerTask:
    """
    Task for computing a segment of the fractal image.
    """

    def __init__(self, start_row, end_row, width, height, center_x, center_y, zoom, max_iter, color_func):
        """
        Initialize the WorkerTask with necessary parameters.

        :param start_row: Starting row of the image segment.
        :param end_row: Ending row of the image segment.
        :param width: Width of the image.
        :param height: Height of the image.
        :param center_x: X-coordinate of the fractal center.
        :param center_y: Y-coordinate of the fractal center.
        :param zoom: Zoom level.
        :param max_iter: Maximum iterations.
        :param color_func: Callable for determining pixel color based on iteration count.
        """
        self.start_row = start_row
        self.end_row = end_row
        self.width = width
        self.height = height
        self.center_x = center_x
        self.center_y = center_y
        self.zoom = zoom
        self.max_iter = max_iter
        self.color_func = color_func

    def __call__(self):
        """
        Compute the color data for the assigned image segment.

        :return: Tuple containing the starting row and the computed image data.
        """
        rows = self.end_row - self.start_row
        result = np.zeros((rows, self.width, 3), dtype=np.uint8)
        for row in range(self.start_row, self.end_row):
            cy = (row - self.height / 2.0) / (0.5 * self.zoom * self.height) + self.center_y
            for col in range(self.width):
                cx = (col - self.width / 2.0) / (0.5 * self.zoom * self.width) + self.center_x
                iteration = MandelbrotMath.compute_iterations(cx, cy, self.max_iter)
                color = self.color_func(iteration)
                result[row - self.start_row, col, :] = color
        return (self.start_row, result)
