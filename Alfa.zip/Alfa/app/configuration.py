# src/app/configuration.py

import configparser
from app.exceptions import InvalidConfigException

class ConfigValidator:
    """
    A class for additional configuration validation.
    It can log warnings if certain values are unusual.
    """

    def __init__(self, config, logger=None):
        """
        Initialize the ConfigValidator with configuration and an optional logger.

        :param config: Instance of Configuration containing configuration parameters.
        :param logger: Instance of LoggerWrapper for logging warnings and info.
        """
        self.config = config
        self.logger = logger

    def validate(self):
        """
        Perform additional validations on the configuration.
        Logs warnings if certain configuration values are outside expected ranges.
        """
        # Check if zoom is extremely large
        if self.config.zoom > 1000:
            msg = f"Zoom value {self.config.zoom} is extremely large, this may cause long computation times."
            if self.logger:
                self.logger.warning(msg)

        # Check if max_iter is too large
        if self.config.max_iter > 10_000_000:
            msg = f"max_iterations={self.config.max_iter} is very large and may cause memory/time issues."
            if self.logger:
                self.logger.warning(msg)

        # For Julia fractals, check the constants range
        if self.config.fractal_type == 'julia':
            if abs(self.config.julia_cx) > 2 or abs(self.config.julia_cy) > 2:
                msg = f"Julia constants cx={self.config.julia_cx}, cy={self.config.julia_cy} are unusual."
                if self.logger:
                    self.logger.warning(msg)

    def report(self):
        """
        Log a summary of the current configuration.
        Useful for debugging and ensuring correct parameters are set.
        """
        if self.logger:
            self.logger.info("Configuration summary:")
            self.logger.info(f"Image: width={self.config.width}, height={self.config.height}")
            self.logger.info(f"Fractal: type={self.config.fractal_type}, center=({self.config.center_x},{self.config.center_y}), zoom={self.config.zoom}, max_iter={self.config.max_iter}")
            if self.config.fractal_type == 'julia':
                self.logger.info(f"Julia Constants: cx={self.config.julia_cx}, cy={self.config.julia_cy}")
            self.logger.info(f"Parallel: {self.config.parallel_strategy} with {self.config.thread_count} workers")
            self.logger.info(f"Output file: {self.config.output_file}")
            self.logger.info(f"Color scheme: {self.config.color_scheme}")

class Configuration:
    """
    A class to load and validate configuration settings from a properties file.
    """

    def __init__(self, config_path):
        """
        Initialize the Configuration by loading and parsing the config file.

        :param config_path: Path to the configuration file.
        :raises InvalidConfigException: If the config file is not found or contains invalid values.
        """
        self.config = configparser.ConfigParser()
        read_files = self.config.read(config_path)
        if not read_files:
            raise InvalidConfigException(f"Config file {config_path} not found.")

        # Load Image settings
        self.width = self._get_int('Image', 'width', 800)
        self.height = self._get_int('Image', 'height', 600)

        # Load Fractal settings
        self.fractal_type = self._get_str('Fractal', 'type', 'mandelbrot')
        self.center_x = self._get_float('Fractal', 'center_x', -0.5)
        self.center_y = self._get_float('Fractal', 'center_y', 0.0)
        self.zoom = self._get_float('Fractal', 'zoom', 1.0)
        self.max_iter = self._get_int('Fractal', 'max_iterations', 1000)
        self.julia_cx = self._get_float('Fractal', 'julia_cx', 0.355)
        self.julia_cy = self._get_float('Fractal', 'julia_cy', 0.355)

        # Load Parallel settings
        self.parallel_strategy = self._get_str('Parallel', 'strategy', 'thread')
        self.thread_count = self._get_int('Parallel', 'thread_count', 4)

        # Load Output settings
        self.output_file = self._get_str('Output', 'file', 'fractal.png')

        # Load Logging settings
        self.log_file = self._get_str('Logging', 'file', 'app.log')

        # Load Color settings
        self.color_scheme = self._get_str('Color', 'scheme', 'default')

        # Validate basic configuration
        self._validate_basic()

    def _validate_basic(self):
        """
        Perform basic validation on configuration parameters.
        Ensures that numerical values are positive where required.
        """
        if self.width <= 0 or self.height <= 0:
            raise InvalidConfigException("Width and Height must be positive integers.")
        if self.max_iter <= 0:
            raise InvalidConfigException("max_iterations must be > 0.")
        if self.thread_count <= 0:
            raise InvalidConfigException("thread_count must be > 0.")

    def _get_int(self, section, option, default):
        """
        Retrieve an integer value from the configuration.

        :param section: Configuration section.
        :param option: Configuration option.
        :param default: Default value if option is not found.
        :return: Integer value of the option.
        :raises InvalidConfigException: If the value cannot be converted to an integer.
        """
        try:
            return self.config.getint(section, option, fallback=default)
        except ValueError:
            raise InvalidConfigException(f"{section}:{option} must be an integer.")

    def _get_float(self, section, option, default):
        """
        Retrieve a float value from the configuration.

        :param section: Configuration section.
        :param option: Configuration option.
        :param default: Default value if option is not found.
        :return: Float value of the option.
        :raises InvalidConfigException: If the value cannot be converted to a float.
        """
        try:
            return self.config.getfloat(section, option, fallback=default)
        except ValueError:
            raise InvalidConfigException(f"{section}:{option} must be a float.")

    def _get_str(self, section, option, default):
        """
        Retrieve a string value from the configuration.

        :param section: Configuration section.
        :param option: Configuration option.
        :param default: Default value if option is not found.
        :return: String value of the option.
        """
        return self.config.get(section, option, fallback=default)
