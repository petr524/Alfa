class InvalidConfigException(Exception):
    """Exception thrown on invalid configuration."""
    pass
