from PIL import Image
import numpy as np

class ImageWriter:
    """
    Save a picture in PNG file.
    """
    @staticmethod
    def save_image(image_data, filename):
        img = Image.fromarray(image_data, 'RGB')
        img.save(filename, 'PNG')
