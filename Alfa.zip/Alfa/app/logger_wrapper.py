import csv
import logging
import os


class LoggerWrapper:
    """
    Singleton logger for the entire application.
    """
    _instance = None

    @classmethod
    def get_instance(cls, log_file='app.log'):
        if cls._instance is None:
            cls._instance = cls._create_logger(log_file)
        return cls._instance

    @classmethod
    def _create_logger(cls, log_file):
        logger = logging.getLogger('FractalLogger')
        logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        logger.addHandler(fh)
        logger.addHandler(ch)
        return logger

    def log_performance_csv(self, csv_file, data_dict):
        """
        Append performance metrics to a CSV file.
        data_dict should be a dict with keys as column names.
        If the file doesn't exist, headers will be written first.
        """
        file_exists = os.path.exists(csv_file)
        fieldnames = list(data_dict.keys())
        with open(csv_file, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow(data_dict)
