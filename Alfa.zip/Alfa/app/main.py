import sys
from logging import config
from venv import logger

from app.configuration import Configuration
from app.logger_wrapper import LoggerWrapper
from app.calculation.strategy_factory import StrategyFactory
from app.exceptions import InvalidConfigException
from app.calculation.mandelbrot_calculator import MandelbrotCalculator
from app.calculation.julia_calculator import JuliaCalculator
from app.image_writer import ImageWriter
from app.model import SystemInfo
from app.configuration import ConfigValidator


def parse_args(args):
    """
   Parse the command line to find the --config parameter.
    """
    if '--config' in args:
        idx = args.index('--config') + 1
        if idx < len(args):
            return args[idx]
    return 'config.properties'

def main():
    """
  Main entrance to the program:
    - Loads the configuration
    - Sets the logger
    - Based on the config, it chooses a parallel strategy
    - Starts a Mandelbrot or Julia set calculation
    - Saves the result
    """
    config_path = parse_args(sys.argv)
    try:
        config = Configuration(config_path)
        logger = LoggerWrapper.get_instance(config.log_file)

        logger.info("Starting fractal calculation.")
        strategy = StrategyFactory.create(config.parallel_strategy, config.thread_count)

        # Výběr typu fractalu
        if config.fractal_type == 'mandelbrot':
            calc = MandelbrotCalculator(config, strategy, logger)
        elif config.fractal_type == 'julia':
            calc = JuliaCalculator(config, strategy, logger)
        else:
            raise InvalidConfigException("Unsupported fractal type in config.")

        image_data = calc.calculate()
        ImageWriter.save_image(image_data, config.output_file)
        logger.info(f"Calculation done. Image saved to {config.output_file}.")
        logger.info("Program finished successfully.")

    except InvalidConfigException as e:
        print(f"Configuration error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

    def main():
            """
            The main entry point of the application:
            - Load configuration
            - Set up logger
            - Validate configuration and log a summary
            - Log system info
            - Based on config, choose fractal type (Mandelbrot or Julia)
            - Run the calculation
            - Save the output image
            """
            config_path = parse_args(sys.argv)
            try:
                config = Configuration(config_path)
                logger = LoggerWrapper.get_instance(config.log_file)

                # Validate configuration and log summary
                config_validator = ConfigValidator(config, logger)
                config_validator.validate()
                config_validator.report()

                # Log system info
                SystemInfo.log_system_info(logger)

                logger.info("Starting fractal calculation.")
                strategy = StrategyFactory.create(config.parallel_strategy, config.thread_count)

                if config.fractal_type == 'mandelbrot':
                    calc = MandelbrotCalculator(config, strategy, logger)
                elif config.fractal_type == 'julia':
                    calc = JuliaCalculator(config, strategy, logger)
                else:
                    raise InvalidConfigException("Unsupported fractal type in config.")

                image_data = calc.calculate()
                ImageWriter.save_image(image_data, config.output_file)
                logger.info(f"Calculation done. Image saved to {config.output_file}.")
                logger.info("Program finished successfully.")

            except InvalidConfigException as e:
                print(f"Configuration error: {e}")
                sys.exit(1)
            except Exception as e:
                print(f"Unexpected error: {e}")
                sys.exit(1)


if __name__ == '__main__':
    main()
