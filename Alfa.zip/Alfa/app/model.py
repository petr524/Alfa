import multiprocessing
import platform
import sys


class MandelbrotParams:
    """
    Uchovává parametry pro výpočet mandelbrotovy množiny. (Nepoužito přímo, ale příklad OOP.)
    """
    def __init__(self, width, height, center_x, center_y, zoom, max_iter):
        self.width = width
        self.height = height
        self.center_x = center_x
        self.center_y = center_y
        self.zoom = zoom
        self.max_iter = max_iter

    import platform
    import multiprocessing
    import sys

class SystemInfo:
        """
        A helper class to log system information:
        - OS name and version
        - CPU count
        - Python version
        """

        @staticmethod
        def log_system_info(logger):
            logger.info("System Information:")
            logger.info(f"Platform: {platform.system()} {platform.release()}")
            logger.info(f"CPU count: {multiprocessing.cpu_count()}")
            logger.info(f"Python version: {sys.version}")
