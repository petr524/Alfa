# test/test_color_schemes.py

import unittest
from app.calculation.color_schemes import ColorSchemes, DefaultColorFunc, BlueishColorFunc, RedishColorFunc, GreenishColorFunc, FallbackColorFunc

class TestColorSchemes(unittest.TestCase):
    def test_default_scheme(self):
        max_iter = 100
        color_func = ColorSchemes.get_color_func('default', max_iter)
        self.assertIsInstance(color_func, DefaultColorFunc)
        # Test a midpoint color
        c = color_func(50)
        self.assertEqual(len(c), 3)
        # When it = max_iter, should be black
        c_black = color_func(100)
        self.assertEqual(c_black, (0, 0, 0))

    def test_blueish_scheme(self):
        max_iter = 200
        color_func = ColorSchemes.get_color_func('blueish', max_iter)
        self.assertIsInstance(color_func, BlueishColorFunc)
        c = color_func(100)
        # In blueish scheme, blue channel increases with iterations
        self.assertTrue(0 <= c[2] <= 255)
        self.assertEqual(c[0], 0)
        self.assertEqual(c[1], 0)

    def test_redish_scheme(self):
        max_iter = 50
        color_func = ColorSchemes.get_color_func('redish', max_iter)
        self.assertIsInstance(color_func, RedishColorFunc)
        c = color_func(25)
        # Check red channel dominance
        self.assertTrue(c[0] > 0)
        self.assertEqual(c[1], 0)
        self.assertEqual(c[2], 0)

    def test_greenish_scheme(self):
        max_iter = 100
        color_func = ColorSchemes.get_color_func('greenish', max_iter)
        self.assertIsInstance(color_func, GreenishColorFunc)
        c = color_func(50)
        # Greenish should increase the green channel
        self.assertEqual(c[0], 0)
        self.assertTrue(c[1] > 0)
        self.assertEqual(c[2], 0)

    def test_fallback_scheme(self):
        max_iter = 100
        color_func = ColorSchemes.get_color_func('unknown_scheme', max_iter)
        self.assertIsInstance(color_func, FallbackColorFunc)
        c = color_func(50)
        # Fallback provides a simple gradient
        self.assertEqual(len(c), 3)

if __name__ == '__main__':
    unittest.main()
