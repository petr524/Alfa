import unittest
import tempfile
import os
from app.configuration import Configuration
from app.exceptions import InvalidConfigException

class TestConfiguration(unittest.TestCase):
    def test_valid_config(self):
        content = """[Image]
width=200
height=100

[Fractal]
type=mandelbrot
center_x=-0.5
center_y=0.0
zoom=1.0
max_iterations=500

[Parallel]
strategy=thread
thread_count=2

[Output]
file=test_output.png

[Logging]
file=test.log

[Color]
scheme=blueish
"""
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tf.write(content.encode('utf-8'))
            tf.flush()
            path = tf.name
        try:
            config = Configuration(path)
            self.assertEqual(config.width, 200)
            self.assertEqual(config.height, 100)
            self.assertEqual(config.max_iter, 500)
            self.assertEqual(config.parallel_strategy, 'thread')
            self.assertEqual(config.thread_count, 2)
            self.assertEqual(config.color_scheme, 'blueish')
        finally:
            os.remove(path)

    def test_invalid_config(self):
        content = """[Image]
width=-10
height=100
"""
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tf.write(content.encode('utf-8'))
            tf.flush()
            path = tf.name
        try:
            with self.assertRaises(InvalidConfigException):
                _ = Configuration(path)
        finally:
            os.remove(path)

if __name__ == '__main__':
    unittest.main()
