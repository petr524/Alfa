import unittest
import tempfile
import os
from app.configuration import Configuration
from app.logger_wrapper import LoggerWrapper
from app.calculation.strategy_factory import StrategyFactory
from app.calculation.mandelbrot_calculator import MandelbrotCalculator
from app.image_writer import ImageWriter

class TestIntegration(unittest.TestCase):
    def test_full_run(self):
        content = """[Image]
width=50
height=50

[Fractal]
type=mandelbrot
center_x=-0.5
center_y=0.0
zoom=1.0
max_iterations=50

[Parallel]
strategy=thread
thread_count=2

[Output]
file=test_mandelbrot.png

[Logging]
file=test.log

[Color]
scheme=redish
"""
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tf.write(content.encode('utf-8'))
            tf.flush()
            path = tf.name
        try:
            config = Configuration(path)
            logger = LoggerWrapper.get_instance(config.log_file)
            strategy = StrategyFactory.create(config.parallel_strategy, config.thread_count)
            calc = MandelbrotCalculator(config, strategy, logger)
            image_data = calc.calculate()

            out_file = os.path.join(tempfile.gettempdir(), "test_mandelbrot_output.png")
            ImageWriter.save_image(image_data, out_file)
            self.assertTrue(os.path.exists(out_file))
            os.remove(out_file)

        finally:
            os.remove(path)

if __name__ == '__main__':
    unittest.main()
