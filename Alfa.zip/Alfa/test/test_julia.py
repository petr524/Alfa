import unittest
import tempfile
import os
from app.configuration import Configuration
from app.logger_wrapper import LoggerWrapper
from app.calculation.strategy_factory import StrategyFactory
from app.calculation.julia_calculator import JuliaCalculator

class TestJulia(unittest.TestCase):
    def test_julia_calculation(self):
        content = """[Image]
width=30
height=30

[Fractal]
type=julia
center_x=0.0
center_y=0.0
zoom=1.0
max_iterations=20
julia_cx=0.355
julia_cy=0.355

[Parallel]
strategy=process
thread_count=2

[Output]
file=julia_test.png

[Logging]
file=test.log

[Color]
scheme=greenish
"""
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tf.write(content.encode('utf-8'))
            tf.flush()
            path = tf.name

        try:
            config = Configuration(path)
            logger = LoggerWrapper.get_instance(config.log_file)
            strategy = StrategyFactory.create(config.parallel_strategy, config.thread_count)
            calc = JuliaCalculator(config, strategy, logger)
            image_data = calc.calculate()
            self.assertEqual(image_data.shape, (30,30,3))
        finally:
            os.remove(path)

if __name__ == '__main__':
    unittest.main()
