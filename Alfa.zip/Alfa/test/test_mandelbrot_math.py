import unittest
from app.calculation.mandelbrot_math import MandelbrotMath

class TestMandelbrotMath(unittest.TestCase):
    def test_point_in_set(self):
        it = MandelbrotMath.compute_iterations(0,0,1000)
        self.assertEqual(it, 1000)

    def test_point_outside_set(self):
        it = MandelbrotMath.compute_iterations(2,2,1000)
        self.assertLess(it, 10)

if __name__ == '__main__':
    unittest.main()
