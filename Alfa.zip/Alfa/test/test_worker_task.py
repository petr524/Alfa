import unittest
from app.calculation.worker_task import WorkerTask
import numpy as np

class TestWorkerTask(unittest.TestCase):
    def test_worker_task_output(self):
        task = WorkerTask(start_row=0, end_row=2, width=3, height=2, center_x=-0.5, center_y=0.0, zoom=1.0, max_iter=50)
        start, data = task()
        self.assertEqual(start, 0)
        self.assertEqual(data.shape, (2, 3, 3))
        self.assertIsInstance(data, np.ndarray)

if __name__ == '__main__':
    unittest.main()
